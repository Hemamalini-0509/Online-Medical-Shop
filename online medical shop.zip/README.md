
  # online medical shop

  This is a code bundle for online medical shop. The original project is available at https://www.figma.com/design/uCUjr2UUW3RCGgpF8AOhR3/online-medical-shop.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  