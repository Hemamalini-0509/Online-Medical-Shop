export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  description: string;
  dosage?: string;
  manufacturer?: string;
  inStock: boolean;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Paracetamol 500mg',
    category: 'Pain Relief',
    price: 5.99,
    originalPrice: 7.99,
    image: 'https://images.unsplash.com/photo-1646392206581-2527b1cae5cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcHJlc2NyaXB0aW9ufGVufDF8fHx8MTc3MDE4NDA1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.5,
    reviews: 128,
    description: 'Effective pain relief and fever reducer. Suitable for adults and children over 12 years.',
    dosage: 'Take 1-2 tablets every 4-6 hours as needed. Do not exceed 8 tablets in 24 hours.',
    manufacturer: 'PharmaCare Ltd.',
    inStock: true,
  },
  {
    id: '2',
    name: 'Vitamin C 1000mg',
    category: 'Vitamins',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXRhbWlucyUyMHN1cHBsZW1lbnRzJTIwYm90dGxlfGVufDF8fHx8MTc3MDIzMjQyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    reviews: 245,
    description: 'High-strength Vitamin C supplement to support immune system health and overall wellness.',
    dosage: 'Take 1 tablet daily with food.',
    manufacturer: 'VitaHealth',
    inStock: true,
  },
  {
    id: '3',
    name: 'First Aid Kit',
    category: 'Medical Equipment',
    price: 24.99,
    originalPrice: 29.99,
    image: 'https://images.unsplash.com/photo-1563260324-5ebeedc8af7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXJzdCUyMGFpZCUyMG1lZGljYWwlMjBraXR8ZW58MXx8fHwxNzcwMjY5MzExfDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    reviews: 89,
    description: 'Complete first aid kit with essential medical supplies for home, office, or travel.',
    manufacturer: 'SafeCare',
    inStock: true,
  },
  {
    id: '4',
    name: 'Digital Thermometer',
    category: 'Medical Devices',
    price: 8.99,
    image: 'https://images.unsplash.com/photo-1615486511473-4e83867c9516?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVybW9tZXRlciUyMG1lZGljYWwlMjBkZXZpY2V8ZW58MXx8fHwxNzcwMjY5MzExfDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.6,
    reviews: 156,
    description: 'Fast and accurate digital thermometer with LCD display. Suitable for oral, rectal, and underarm use.',
    manufacturer: 'MediTech',
    inStock: true,
  },
  {
    id: '5',
    name: 'Hand Sanitizer 500ml',
    category: 'Hygiene',
    price: 6.49,
    image: 'https://images.unsplash.com/photo-1614669961117-2ff08082a44f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kJTIwc2FuaXRpemVyJTIwaGVhbHRoY2FyZXxlbnwxfHx8fDE3NzAyNjkzMTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.4,
    reviews: 201,
    description: '70% alcohol-based hand sanitizer. Kills 99.9% of germs. Moisturizing formula with aloe vera.',
    manufacturer: 'CleanCare',
    inStock: true,
  },
  {
    id: '6',
    name: 'Ibuprofen 200mg',
    category: 'Pain Relief',
    price: 7.49,
    image: 'https://images.unsplash.com/photo-1646392206581-2527b1cae5cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcHJlc2NyaXB0aW9ufGVufDF8fHx8MTc3MDE4NDA1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.6,
    reviews: 178,
    description: 'Anti-inflammatory pain relief for headaches, muscle aches, and fever.',
    dosage: 'Take 1-2 tablets every 4-6 hours. Do not exceed 6 tablets in 24 hours.',
    manufacturer: 'PharmaCare Ltd.',
    inStock: true,
  },
  {
    id: '7',
    name: 'Multivitamin Complex',
    category: 'Vitamins',
    price: 15.99,
    image: 'https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXRhbWlucyUyMHN1cHBsZW1lbnRzJTIwYm90dGxlfGVufDF8fHx8MTc3MDIzMjQyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    reviews: 312,
    description: 'Complete daily multivitamin with essential vitamins and minerals for overall health.',
    dosage: 'Take 1 tablet daily with breakfast.',
    manufacturer: 'VitaHealth',
    inStock: true,
  },
  {
    id: '8',
    name: 'Blood Pressure Monitor',
    category: 'Medical Devices',
    price: 39.99,
    originalPrice: 49.99,
    image: 'https://images.unsplash.com/photo-1615486511473-4e83867c9516?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVybW9tZXRlciUyMG1lZGljYWwlMjBkZXZpY2V8ZW58MXx8fHwxNzcwMjY5MzExfDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.5,
    reviews: 94,
    description: 'Automatic blood pressure monitor with large display and memory function.',
    manufacturer: 'MediTech',
    inStock: true,
  },
];

export const categories = [
  'All',
  'Pain Relief',
  'Vitamins',
  'Medical Equipment',
  'Medical Devices',
  'Hygiene',
];
